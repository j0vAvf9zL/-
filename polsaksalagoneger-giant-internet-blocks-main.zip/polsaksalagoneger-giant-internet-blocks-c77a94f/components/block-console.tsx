"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowUp,
  CircleDot,
  Coins,
  Download,
  Factory,
  HardDrive,
  Loader2,
  ScrollText,
  Terminal,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { BlockRecord, BlockStats, FactoryState } from "@/lib/models";

const numberFormat = new Intl.NumberFormat("ru-RU");
const percentFormat = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 6,
  maximumFractionDigits: 6,
});
const compactFormat = new Intl.NumberFormat("ru-RU", {
  notation: "compact",
  maximumFractionDigits: 2,
});
const petabytesFormat = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

type LogTone = "info" | "ok" | "warn";

interface LogLine {
  time: string;
  text: string;
  tone: LogTone;
}

interface TerminalMeta {
  productName: string;
  version: string;
  mode: string;
}

interface BlockConsoleProps {
  initialStats: BlockStats;
  initialBlocks: BlockRecord[];
  dbAvailable: boolean;
  terminalMeta: TerminalMeta;
  initialFactory: FactoryState;
  initialLog: LogLine[];
}

function formatUtc(iso: string): string {
  return iso
    .replace("T", " ")
    .replace(/\.\d{3}Z$/, "")
    .concat(" UTC");
}

function nowClock(): string {
  return new Date().toISOString().split("T")[1].slice(0, 8);
}

function formatRate(bps: number): string {
  if (bps < 1) {
    const seconds = 1 / bps;
    const label = Number.isInteger(seconds)
      ? String(seconds)
      : seconds.toFixed(1);
    return `1 блок / ${label} с`;
  }
  return `${bps} блок/с`;
}

function PanelTitle({
  icon,
  children,
}: {
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-600">
      {icon}
      {children}
    </div>
  );
}

export function BlockConsole({
  initialStats,
  initialBlocks,
  dbAvailable,
  terminalMeta,
  initialFactory,
  initialLog,
}: BlockConsoleProps) {
  const [stats, setStats] = useState<BlockStats>(initialStats);
  const [blocks, setBlocks] = useState<BlockRecord[]>(initialBlocks);
  const [factory, setFactory] = useState<FactoryState>(initialFactory);
  const [log, setLog] = useState<LogLine[]>(initialLog);
  const [releasing, setReleasing] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [exactValues, setExactValues] = useState(false);
  const factoryMaxNumberRef = useRef<number | null>(null);

  const pushLog = useCallback((text: string, tone: LogTone = "info") => {
    setLog((prev) => [...prev, { time: nowClock(), text, tone }].slice(-9));
  }, []);

  const detectFactoryProduction = useCallback(
    (list: BlockRecord[]) => {
      const factoryBlocks = list.filter((block) => block.source === "factory");
      if (factoryBlocks.length === 0) return;

      const maxNumber = Math.max(...factoryBlocks.map((block) => block.number));

      if (factoryMaxNumberRef.current === null) {
        factoryMaxNumberRef.current = maxNumber;
        return;
      }

      const newOnes = factoryBlocks
        .filter((block) => block.number > factoryMaxNumberRef.current!)
        .sort((a, b) => b.number - a.number);

      if (newOnes.length === 0) return;

      for (const block of newOnes.slice(0, 5)) {
        pushLog(
          `ФАБРИКА: ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
      }

      factoryMaxNumberRef.current = maxNumber;
    },
    [pushLog]
  );

  const refresh = useCallback(async () => {
    const [blocksResponse, factoryResponse] = await Promise.all([
      fetch("/api/blocks"),
      fetch("/api/factory").catch(() => null),
    ]);

    if (blocksResponse.ok) {
      const data = await blocksResponse.json();
      if (data && typeof data === "object") {
        if (data.stats) setStats(data.stats);
        if (Array.isArray(data.blocks)) {
          setBlocks(data.blocks);
          detectFactoryProduction(data.blocks);
        }
      }
    }

    if (factoryResponse?.ok) {
      const data = await factoryResponse.json();
      if (data?.factory) setFactory(data.factory);
    }
  }, [detectFactoryProduction]);

  useEffect(() => {
    const factoryBlocks = initialBlocks.filter(
      (block) => block.source === "factory"
    );
    if (factoryBlocks.length > 0) {
      factoryMaxNumberRef.current = Math.max(
        ...factoryBlocks.map((block) => block.number)
      );
      for (const block of factoryBlocks.slice(0, 2)) {
        pushLog(
          `ФАБРИКА: ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!dbAvailable) return;
    const interval = setInterval(refresh, 4000);
    return () => clearInterval(interval);
  }, [dbAvailable, refresh]);

  const handleRelease = async () => {
    if (releasing) return;
    setReleasing(true);
    const id = toast.loading("Создаём блок на 10 ГБ...");
    try {
      const response = await fetch("/api/blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const block: BlockRecord = await response.json();
        pushLog(
          `ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
        await refresh();
        toast.success(`Блок #${numberFormat.format(block.number)} выпущен`, {
          id,
        });
      } else {
        const error = await response.json().catch(() => null);
        toast.error(error?.error || "Ошибка выпуска блока", { id });
      }
    } catch {
      toast.error("Ошибка соединения с сервером", { id });
    } finally {
      setReleasing(false);
    }
  };

  const handleUpgrade = async () => {
    if (upgrading || !dbAvailable) return;
    setUpgrading(true);
    const id = toast.loading("Улучшаем фабрику...");
    try {
      const response = await fetch("/api/factory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const data = await response.json();
        setFactory(data.factory);
        pushLog(
          `ФАБРИКА: УРОВЕНЬ ${data.factory.level} — СКОРОСТЬ ${formatRate(data.factory.blocksPerSecond)} — OK`,
          "ok"
        );
        await refresh();
        toast.success(`Фабрика улучшена до уровня ${data.factory.level}`, {
          id,
        });
      } else {
        const error = await response.json().catch(() => null);
        toast.error(error?.error || "Ошибка улучшения фабрики", { id });
      }
    } catch {
      toast.error("Ошибка соединения с сервером", { id });
    } finally {
      setUpgrading(false);
    }
  };

  const percent = (stats.released / stats.target) * 100;
  const totalVolumePb = (stats.released * stats.blockSizeGb) / 1_000_000;
  const releasedLabel = exactValues
    ? numberFormat.format(stats.released)
    : compactFormat.format(stats.released);
  const targetLabel = exactValues
    ? numberFormat.format(stats.target)
    : compactFormat.format(stats.target);
  const volumeLabel = exactValues
    ? `${numberFormat.format(stats.totalBytes)} байт`
    : `${petabytesFormat.format(totalVolumePb)} ПБ`;
  const atMaxLevel = factory.level >= factory.maxLevel;
  const canAfford = factory.coins >= factory.upgradePrice;
  const upgradeDisabled = !dbAvailable || upgrading || atMaxLevel || !canAfford;

  return (
    <div className="min-h-[calc(100vh-8rem)] bg-[#030605] px-4 py-8 font-mono text-emerald-400 sm:px-6">
      <div className="mx-auto max-w-6xl overflow-hidden rounded-lg border border-emerald-900/70 bg-[#070c09] shadow-[0_0_60px_rgba(16,185,129,0.08)]">
        <div className="flex items-center gap-2 border-b border-emerald-900/70 bg-[#0a100c] px-4 py-2.5">
          <span className="size-2.5 rounded-full bg-[#ff5f56]" />
          <span className="size-2.5 rounded-full bg-[#ffbd2e]" />
          <span className="size-2.5 rounded-full bg-[#27c93f]" />
          <span className="ml-3 text-[11px] uppercase tracking-[0.2em] text-emerald-700">
            {terminalMeta.productName} — генератор {terminalMeta.version}
          </span>
          <span className="ml-auto hidden text-[11px] text-emerald-800 sm:block">
            root@blocks-internet:~$
          </span>
        </div>

        <div className="grid gap-0 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="space-y-6 border-b border-emerald-900/50 p-5 sm:p-7 lg:border-r">
            <section className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <PanelTitle icon={<CircleDot className="size-3.5" />}>
                  Выпущено блоков
                </PanelTitle>
                <button
                  type="button"
                  onClick={() => setExactValues((value) => !value)}
                  title={
                    exactValues
                      ? "Показать сокращённо"
                      : "Показать точные значения"
                  }
                  className={cn(
                    "rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50",
                    exactValues
                      ? "border-amber-600/60 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                      : "border-emerald-800/70 bg-emerald-950/40 text-emerald-600 hover:text-emerald-400"
                  )}
                >
                  {exactValues ? "Сокращённо" : "Точные значения"}
                </button>
              </div>
              <div
                className="text-4xl font-bold tracking-tight text-emerald-300 tabular-nums sm:text-6xl"
                title={
                  exactValues
                    ? undefined
                    : `Точное значение: ${numberFormat.format(stats.released)}`
                }
              >
                {releasedLabel}
              </div>
              <div className="text-sm text-emerald-700">
                из цели{" "}
                <span
                  className="font-semibold text-amber-500 tabular-nums"
                  title={
                    exactValues
                      ? undefined
                      : `Точное значение: ${numberFormat.format(stats.target)}`
                  }
                >
                  {targetLabel}
                </span>
                <span className="ml-2 text-amber-500/80 tabular-nums">
                  ({percentFormat.format(percent)} %)
                </span>
              </div>
            </section>

            <section className="space-y-2">
              <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.25em] text-emerald-600">
                <span>Прогресс</span>
                <span className="text-amber-500 tabular-nums">
                  {percentFormat.format(percent)} %
                </span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-none border border-emerald-900 bg-black/60">
                <div
                  className="h-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-300"
                  style={{ width: `${percent}%`, minWidth: 2 }}
                />
              </div>
              <p className="text-xs text-emerald-700">
                суммарный объём:{" "}
                <span
                  className="text-emerald-400 tabular-nums"
                  title={
                    exactValues
                      ? undefined
                      : `Точное значение: ${numberFormat.format(stats.totalBytes)} байт`
                  }
                >
                  {volumeLabel}
                </span>
              </p>
            </section>

            <section className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <button
                type="button"
                onClick={handleRelease}
                disabled={!dbAvailable || releasing}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-sm border border-amber-500/70 bg-amber-500/10 px-6 text-sm font-semibold uppercase tracking-[0.2em] text-amber-400 transition-colors hover:bg-amber-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50"
              >
                {releasing ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Zap className="size-4" />
                )}
                {releasing ? "Создание..." : "Выпустить блок"}
              </button>
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-emerald-700">
                <HardDrive className="size-3.5" />1 блок = {stats.blockSizeGb}{" "}
                ГБ данных
              </div>
            </section>

            {!dbAvailable && (
              <p className="rounded-sm border border-amber-800/60 bg-amber-950/30 px-3 py-2 text-xs text-amber-500/90">
                База данных недоступна — выпуск отключён, показаны статические
                данные.
              </p>
            )}

            <section className="space-y-3 rounded-sm border border-emerald-900/70 bg-black/30 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-500">
                  <Factory className="size-4" />
                  Автоматическая фабрика
                </div>
                <span
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-[0.2em]",
                    dbAvailable
                      ? "border-emerald-700/60 bg-emerald-500/10 text-emerald-400"
                      : "border-amber-700/60 bg-amber-500/10 text-amber-500"
                  )}
                >
                  <span
                    className={cn(
                      "size-1.5 animate-pulse rounded-full",
                      dbAvailable ? "bg-emerald-400" : "bg-amber-500"
                    )}
                  />
                  {dbAvailable ? "Онлайн" : "Офлайн"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Уровень
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {factory.level}
                    <span className="ml-1 text-sm font-normal text-emerald-700">
                      / {factory.maxLevel}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Скорость
                  </div>
                  <div className="text-2xl font-bold text-amber-400 tabular-nums">
                    {formatRate(factory.blocksPerSecond)}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    <Coins className="size-3" />
                    Монеты
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {numberFormat.format(factory.coins)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Блоков фабрикой
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {compactFormat.format(factory.totalFactoryBlocks)}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleUpgrade}
                disabled={upgradeDisabled}
                title={
                  atMaxLevel
                    ? "Достигнут максимальный уровень"
                    : !canAfford
                      ? `Не хватает ${numberFormat.format(factory.upgradePrice - factory.coins)} монет`
                      : undefined
                }
                className={cn(
                  "inline-flex h-9 w-full items-center justify-center gap-2 rounded-sm border px-4 text-xs font-semibold uppercase tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60",
                  atMaxLevel
                    ? "border-emerald-800/60 bg-emerald-950/30 text-emerald-600"
                    : canAfford
                      ? "border-amber-500/70 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                      : "border-emerald-700/60 bg-emerald-500/5 text-emerald-500"
                )}
              >
                {upgrading ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <ArrowUp className="size-3.5" />
                )}
                {atMaxLevel
                  ? "Макс. уровень"
                  : `Улучшить скорость — ${numberFormat.format(factory.upgradePrice)} монет`}
              </button>
            </section>
          </div>

          <div className="space-y-6 p-5 sm:p-7">
            <section className="space-y-3">
              <PanelTitle icon={<Terminal className="size-4" />}>
                Лог терминала
              </PanelTitle>
              <div className="max-h-64 overflow-y-auto rounded-sm border border-emerald-900/70 bg-black/50 p-4 text-xs leading-relaxed">
                {log.map((line, i) => (
                  <div key={i} className="flex gap-3 whitespace-pre-wrap">
                    <span className="shrink-0 text-amber-500/80 tabular-nums">
                      [{line.time}]
                    </span>
                    <span
                      className={cn(
                        line.tone === "ok" && "text-emerald-400",
                        line.tone === "warn" && "text-amber-400",
                        line.tone === "info" && "text-emerald-300/80"
                      )}
                    >
                      {line.text}
                    </span>
                  </div>
                ))}
                <div className="mt-1 flex items-center gap-1 text-emerald-500">
                  <span>&gt;</span>
                  <span className="inline-block h-3.5 w-2 animate-pulse bg-emerald-400" />
                </div>
              </div>
            </section>

            <section className="space-y-3">
              <PanelTitle icon={<ScrollText className="size-4" />}>
                История выпусков
              </PanelTitle>
              <div className="divide-y divide-emerald-900/50 rounded-sm border border-emerald-900/70 bg-black/50">
                {blocks.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 px-4 py-10 text-center">
                    <div className="flex size-12 items-center justify-center rounded-full bg-emerald-950/60">
                      <ScrollText className="size-6 text-emerald-700" />
                    </div>
                    <p className="text-sm text-emerald-700">
                      Блоки ещё не выпущены
                    </p>
                    {dbAvailable && (
                      <p className="text-xs text-emerald-800">
                        Нажмите «Выпустить блок», чтобы создать первый блок на
                        10 ГБ
                      </p>
                    )}
                  </div>
                ) : (
                  blocks.map((release) => (
                    <div
                      key={release.id}
                      className="grid grid-cols-[auto_1fr] items-center gap-x-3 gap-y-1 px-4 py-2.5 text-xs sm:grid-cols-[auto_1fr_auto] sm:gap-y-0"
                    >
                      <span className="font-semibold text-amber-400 tabular-nums">
                        #{numberFormat.format(release.number)}
                      </span>
                      <span className="text-emerald-500/80">
                        {formatUtc(release.releasedAt)}
                      </span>
                      <div className="col-span-2 flex flex-wrap items-center gap-2 sm:col-span-1">
                        {release.source === "factory" ? (
                          <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-800/60 bg-emerald-950/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-500">
                            <Factory className="size-2.5" />
                            Фабрика
                          </span>
                        ) : (
                          <span className="rounded-sm border border-emerald-900/60 bg-black/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-700">
                            Ручной
                          </span>
                        )}
                        <span className="text-emerald-400 tabular-nums">
                          {release.sizeGb} ГБ
                        </span>
                        <span className="text-emerald-800 tabular-nums">
                          ({numberFormat.format(release.sizeBytes)} байт)
                        </span>
                        {release.status === "generating" ? (
                          <span className="inline-flex items-center gap-1.5 rounded-sm border border-amber-600/60 bg-amber-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-amber-400">
                            <Loader2 className="size-3 animate-spin" />
                            Генерация...
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-emerald-400">
                            <span className="size-1.5 rounded-full bg-emerald-400" />
                            Готов
                          </span>
                        )}
                        {dbAvailable && release.status === "ready" && (
                          <a
                            href={`/api/blocks/${release.number}/download`}
                            download
                            className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-amber-400 transition-colors hover:bg-amber-500/25"
                          >
                            <Download className="size-3" />
                            Скачать
                          </a>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-emerald-900/70 bg-[#0a100c] px-4 py-2 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
          <span>
            статус: <span className="text-amber-500">{terminalMeta.mode}</span>
          </span>
          <span>
            режим:{" "}
            <span className="text-emerald-400">
              {dbAvailable ? "динамический" : "статический"}
            </span>
          </span>
          <span className="ml-auto hidden sm:block">uptime: 99:99:99</span>
          <span className="inline-block h-3 w-2 animate-pulse bg-emerald-500" />
        </div>
      </div>
    </div>
  );
}
