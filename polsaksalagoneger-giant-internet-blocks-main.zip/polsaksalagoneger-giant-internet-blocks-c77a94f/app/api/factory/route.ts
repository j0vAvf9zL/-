import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { ensureFactoryEngineStarted } from "@/lib/factory-engine";
import { getFactoryState, upgradeFactory } from "@/lib/models";
import { mockFactoryState } from "@/lib/mock-data";

const upgradeSchema = z.object({});

export const dynamic = "force-dynamic";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      await ensureFactoryEngineStarted();
      const factory = await getFactoryState();
      return NextResponse.json({ factory, dbAvailable: true });
    } catch (error) {
      console.error("Ошибка получения состояния фабрики:", error);
      return NextResponse.json(
        { error: "Ошибка получения состояния фабрики" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ factory: mockFactoryState, dbAvailable: false });
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    let body: unknown = {};
    try {
      body = await request.json();
    } catch {
      void 0;
    }

    const parsed = upgradeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const factory = await upgradeFactory();
    await ensureFactoryEngineStarted();
    return NextResponse.json({ factory, dbAvailable: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "MAX_LEVEL") {
      return NextResponse.json(
        { error: "Фабрика уже достигла максимального уровня" },
        { status: 400 }
      );
    }
    if (message === "INSUFFICIENT_COINS") {
      return NextResponse.json(
        { error: "Недостаточно монет для улучшения" },
        { status: 409 }
      );
    }
    console.error("Ошибка улучшения фабрики:", error);
    return NextResponse.json(
      { error: "Ошибка улучшения фабрики" },
      { status: 500 }
    );
  }
}
