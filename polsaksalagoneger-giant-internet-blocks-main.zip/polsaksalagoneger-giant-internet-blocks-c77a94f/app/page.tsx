import { isDatabaseAvailable } from "@/lib/db";
import {
  getBlocksOverview,
  getFactoryState,
  type FactoryState,
} from "@/lib/models";
import { mockBlocks, mockBlockStats, mockFactoryState } from "@/lib/mock-data";
import { TERMINAL_LOG, TERMINAL_META } from "@/lib/data";
import { BlockConsole } from "@/components/block-console";

export const dynamic = "force-dynamic";

async function getOverview() {
  if (await isDatabaseAvailable()) {
    try {
      return { overview: await getBlocksOverview(), dbAvailable: true };
    } catch {
      // fall back to mock data
    }
  }
  return {
    overview: { stats: mockBlockStats, blocks: mockBlocks },
    dbAvailable: false,
  };
}

async function getFactory(): Promise<{
  factory: FactoryState;
  dbAvailable: boolean;
}> {
  if (await isDatabaseAvailable()) {
    try {
      return { factory: await getFactoryState(), dbAvailable: true };
    } catch {
      // fall back to mock data
    }
  }
  return { factory: mockFactoryState, dbAvailable: false };
}

export default async function HomePage() {
  const [{ overview, dbAvailable }, { factory }] = await Promise.all([
    getOverview(),
    getFactory(),
  ]);

  return (
    <BlockConsole
      initialStats={overview.stats}
      initialBlocks={overview.blocks}
      dbAvailable={dbAvailable}
      terminalMeta={TERMINAL_META}
      initialFactory={factory}
      initialLog={TERMINAL_LOG}
    />
  );
}
