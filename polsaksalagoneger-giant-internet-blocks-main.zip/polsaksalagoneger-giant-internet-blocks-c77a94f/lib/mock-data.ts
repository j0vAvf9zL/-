// Мок-данные для статического режима (без БД)
// Используются когда USE_DATABASE=false или БД недоступна

import { Service, BlockRecord, BlockStats, FactoryState } from "./models";
import {
  BLOCK_SIZE_BYTES,
  BLOCK_SIZE_GB,
  TARGET_BLOCK_COUNT,
} from "./block-file";
import {
  DEFAULT_FACTORY_LEVEL,
  MAX_FACTORY_LEVEL,
  blocksPerSecondForLevel,
  upgradePriceForLevel,
} from "./factory";

export const mockServices: Service[] = [
  {
    id: "mock-service-1",
    name: "API Gateway",
    description: "Шлюз для микросервисной архитектуры",
    status: "active",
    url: "https://api.example.com",
    createdAt: new Date("2024-01-15").toISOString(),
    updatedAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "mock-service-2",
    name: "Auth Service",
    description: "Сервис аутентификации и авторизации",
    status: "active",
    url: "https://auth.example.com",
    createdAt: new Date("2024-02-01").toISOString(),
    updatedAt: new Date("2024-02-01").toISOString(),
  },
  {
    id: "mock-service-3",
    name: "ML Pipeline",
    description: "Пайплайн для обработки данных с AI",
    status: "deploying",
    url: undefined,
    createdAt: new Date("2024-03-10").toISOString(),
    updatedAt: new Date("2024-03-10").toISOString(),
  },
];

export const mockBlockStats: BlockStats = {
  released: 42_737_615,
  target: TARGET_BLOCK_COUNT,
  blockSizeGb: BLOCK_SIZE_GB,
  totalBytes: 42_737_615 * BLOCK_SIZE_BYTES,
};

export const mockFactoryState: FactoryState = {
  level: DEFAULT_FACTORY_LEVEL,
  blocksPerSecond: blocksPerSecondForLevel(DEFAULT_FACTORY_LEVEL),
  coins: 2_500_000,
  totalFactoryBlocks: 3,
  upgradePrice: upgradePriceForLevel(DEFAULT_FACTORY_LEVEL),
  maxLevel: MAX_FACTORY_LEVEL,
  startedAt: new Date("2024-01-15").toISOString(),
  updatedAt: new Date("2024-01-15").toISOString(),
};

function mockBlock(
  number: number,
  minutesAgo: number,
  generatingMs = 0
): BlockRecord {
  const releasedAt = new Date(Date.now() - minutesAgo * 60_000).toISOString();
  const readyAt = new Date(Date.parse(releasedAt) + generatingMs).toISOString();
  return {
    id: `mock-block-${number}`,
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    sizeGb: BLOCK_SIZE_GB,
    releasedAt,
    readyAt,
    status: generatingMs > 0 ? "generating" : "ready",
    fileName: `block-${number}.bin`,
    source: "factory",
  };
}

export const mockBlocks: BlockRecord[] = [
  mockBlock(42_737_615, 5, 120_000),
  mockBlock(42_737_614, 10),
  mockBlock(42_737_613, 15),
  mockBlock(42_737_612, 20),
  mockBlock(42_737_611, 25),
  mockBlock(42_737_610, 30),
];
