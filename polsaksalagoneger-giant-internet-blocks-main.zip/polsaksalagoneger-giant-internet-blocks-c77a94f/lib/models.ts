import { docClient } from "./db";
import {
  GetCommand,
  PutCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import { TableName, IndexName } from "./schema";
import {
  BLOCK_GENERATION_MS,
  BLOCK_SIZE_BYTES,
  BLOCK_SIZE_GB,
  TARGET_BLOCK_COUNT,
} from "./block-file";
import {
  COINS_PER_BLOCK,
  DEFAULT_FACTORY_LEVEL,
  MAX_FACTORY_LEVEL,
  blocksPerSecondForLevel,
  upgradePriceForLevel,
} from "./factory";

export const INITIAL_BLOCK_COUNT = 42_737_615;

const BLOCK_PK = "block";
const COUNTER_PK = "counter";
const COUNTER_SK = "global";
const FACTORY_PK = "factory";
const FACTORY_SK = "state";

function padBlockNumber(number: number): string {
  return String(number).padStart(15, "0");
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  status: "active" | "inactive" | "deploying";
  url?: string;
  createdAt: string;
  updatedAt: string;
}

export async function getServiceById(id: string): Promise<Service | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
  return (result.Item as Service) ?? null;
}

export async function getServicesByStatus(status: string): Promise<Service[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.SERVICES,
      IndexName: IndexName.SERVICES_STATUS,
      KeyConditionExpression: "#status = :status",
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ExpressionAttributeValues: {
        ":status": status,
      },
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function getAllServices(): Promise<Service[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SERVICES,
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function createService(
  data: Omit<Service, "createdAt" | "updatedAt">
): Promise<Service> {
  const now = new Date().toISOString();
  const service: Service = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.SERVICES,
      Item: service,
    })
  );

  return service;
}

export async function updateService(
  id: string,
  data: Partial<Pick<Service, "name" | "description" | "status" | "url">>
): Promise<Service> {
  const updateExpr = [];
  const exprValues: Record<string, unknown> = {};
  const exprNames: Record<string, string> = {};

  if (data.name !== undefined) {
    updateExpr.push("#name = :name");
    exprValues[":name"] = data.name;
    exprNames["#name"] = "name";
  }

  if (data.description !== undefined) {
    updateExpr.push("#description = :description");
    exprValues[":description"] = data.description;
    exprNames["#description"] = "description";
  }

  if (data.status !== undefined) {
    updateExpr.push("#status = :status");
    exprValues[":status"] = data.status;
    exprNames["#status"] = "status";
  }

  if (data.url !== undefined) {
    updateExpr.push("#url = :url");
    exprValues[":url"] = data.url;
    exprNames["#url"] = "url";
  }

  updateExpr.push("updatedAt = :updatedAt");
  exprValues[":updatedAt"] = new Date().toISOString();

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.SERVICES,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames:
        Object.keys(exprNames).length > 0 ? exprNames : undefined,
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Service;
}

export async function deleteService(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
}

export type BlockStatus = "generating" | "ready";
export type BlockSource = "manual" | "factory";

export interface BlockRecord {
  id: string;
  number: number;
  sizeBytes: number;
  sizeGb: number;
  releasedAt: string;
  readyAt: string;
  status: BlockStatus;
  fileName: string;
  source: BlockSource;
}

export interface BlockStats {
  released: number;
  target: number;
  blockSizeGb: number;
  totalBytes: number;
}

export interface BlocksOverview {
  stats: BlockStats;
  blocks: BlockRecord[];
}

export interface FactoryState {
  level: number;
  blocksPerSecond: number;
  coins: number;
  totalFactoryBlocks: number;
  upgradePrice: number;
  maxLevel: number;
  startedAt: string;
  updatedAt: string;
}

async function ensureCounter(): Promise<void> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
    })
  );

  if (!result.Item) {
    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: { pk: COUNTER_PK, sk: COUNTER_SK, count: INITIAL_BLOCK_COUNT },
      })
    );
  }
}

async function nextBlockNumber(): Promise<number> {
  await ensureCounter();
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
      UpdateExpression: "ADD #count :one",
      ExpressionAttributeNames: { "#count": "count" },
      ExpressionAttributeValues: { ":one": 1 },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes?.count as number) ?? 0;
}

export async function getBlockStats(): Promise<BlockStats> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
    })
  );

  let released = result.Item?.count as number | undefined;
  if (released === undefined) {
    await ensureCounter();
    released = INITIAL_BLOCK_COUNT;
  }

  return {
    released,
    target: TARGET_BLOCK_COUNT,
    blockSizeGb: BLOCK_SIZE_GB,
    totalBytes: released * BLOCK_SIZE_BYTES,
  };
}

function blockStatus(readyAt?: string): BlockStatus {
  if (!readyAt) return "ready";
  return new Date(readyAt).getTime() <= Date.now() ? "ready" : "generating";
}

function toBlockRecord(item: Record<string, unknown>): BlockRecord {
  const readyAt =
    (item.readyAt as string | undefined) ??
    (item.releasedAt as string) ??
    new Date().toISOString();
  return {
    id: item.id as string,
    number: item.number as number,
    sizeBytes: item.sizeBytes as number,
    sizeGb: item.sizeGb as number,
    releasedAt: item.releasedAt as string,
    readyAt,
    status: blockStatus(readyAt),
    fileName: item.fileName as string,
    source: (item.source as BlockSource | undefined) ?? "manual",
  };
}

export async function createBlock(
  source: BlockSource = "manual"
): Promise<BlockRecord> {
  const number = await nextBlockNumber();
  const releasedAt = new Date().toISOString();
  const readyAt = new Date(Date.now() + BLOCK_GENERATION_MS).toISOString();
  const block: BlockRecord = {
    id: crypto.randomUUID(),
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    sizeGb: BLOCK_SIZE_GB,
    releasedAt,
    readyAt,
    status: "generating",
    fileName: `block-${number}.bin`,
    source,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.BLOCKS,
      Item: {
        pk: BLOCK_PK,
        sk: padBlockNumber(number),
        ...block,
      },
    })
  );

  await creditCoins(COINS_PER_BLOCK);

  return block;
}

export async function getBlockByNumber(
  number: number
): Promise<BlockRecord | null> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk AND sk = :sk",
      ExpressionAttributeValues: {
        ":pk": BLOCK_PK,
        ":sk": padBlockNumber(number),
      },
      Limit: 1,
    })
  );
  const item = result.Items?.[0];
  if (!item) return null;
  return toBlockRecord(item as Record<string, unknown>);
}

export async function listBlocks(limit = 50): Promise<BlockRecord[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk",
      ExpressionAttributeValues: { ":pk": BLOCK_PK },
      ScanIndexForward: false,
      Limit: limit,
    })
  );
  return (result.Items ?? []).map((item) =>
    toBlockRecord(item as Record<string, unknown>)
  );
}

export async function getBlocksOverview(): Promise<BlocksOverview> {
  const [stats, blocks] = await Promise.all([getBlockStats(), listBlocks(50)]);
  return { stats, blocks };
}

function normalizeFactoryItem(item: Record<string, unknown>): FactoryState {
  const level = (item.level as number | undefined) ?? DEFAULT_FACTORY_LEVEL;
  return {
    level,
    blocksPerSecond: blocksPerSecondForLevel(level),
    coins: (item.coins as number | undefined) ?? 0,
    totalFactoryBlocks: (item.totalFactoryBlocks as number | undefined) ?? 0,
    upgradePrice: upgradePriceForLevel(level),
    maxLevel: MAX_FACTORY_LEVEL,
    startedAt: (item.startedAt as string | undefined) ?? "",
    updatedAt: (item.updatedAt as string | undefined) ?? "",
  };
}

async function seedFactoryState(): Promise<void> {
  const now = new Date().toISOString();
  try {
    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: {
          pk: FACTORY_PK,
          sk: FACTORY_SK,
          level: DEFAULT_FACTORY_LEVEL,
          coins: 0,
          totalFactoryBlocks: 0,
          startedAt: now,
          updatedAt: now,
        },
        ConditionExpression: "attribute_not_exists(pk)",
      })
    );
  } catch {
    void 0;
  }
}

async function creditCoins(amount: number): Promise<void> {
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression: "ADD #coins :amount",
      ExpressionAttributeNames: { "#coins": "coins" },
      ExpressionAttributeValues: { ":amount": amount },
    })
  );
}

export async function getFactoryState(): Promise<FactoryState> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
    })
  );

  if (!result.Item) {
    await seedFactoryState();
    const seeded = await docClient.send(
      new GetCommand({
        TableName: TableName.BLOCKS,
        Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      })
    );
    return normalizeFactoryItem((seeded.Item as Record<string, unknown>) ?? {});
  }

  return normalizeFactoryItem(result.Item as Record<string, unknown>);
}

export async function upgradeFactory(): Promise<FactoryState> {
  const state = await getFactoryState();

  if (state.level >= state.maxLevel) {
    throw new Error("MAX_LEVEL");
  }

  const price = state.upgradePrice;
  if (state.coins < price) {
    throw new Error("INSUFFICIENT_COINS");
  }

  const now = new Date().toISOString();
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression:
        "SET #level = :level, updatedAt = :updatedAt ADD #coins :minusCoins",
      ExpressionAttributeNames: { "#level": "level", "#coins": "coins" },
      ExpressionAttributeValues: {
        ":level": state.level + 1,
        ":updatedAt": now,
        ":minusCoins": -price,
        ":price": price,
      },
      ConditionExpression: "#coins >= :price",
      ReturnValues: "ALL_NEW",
    })
  );

  return normalizeFactoryItem(result.Attributes as Record<string, unknown>);
}

export async function produceFactoryBlock(): Promise<BlockRecord> {
  const block = await createBlock("factory");
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression: "ADD #total :one",
      ExpressionAttributeNames: { "#total": "totalFactoryBlocks" },
      ExpressionAttributeValues: { ":one": 1 },
    })
  );
  return block;
}
