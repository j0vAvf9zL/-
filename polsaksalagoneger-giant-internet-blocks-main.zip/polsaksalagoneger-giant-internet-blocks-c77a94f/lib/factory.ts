export const DEFAULT_FACTORY_LEVEL = 1;
export const MAX_FACTORY_LEVEL = 8;

export const FACTORY_LEVELS_BPS = [0.1, 0.2, 0.5, 1, 2, 4, 8, 16];

export const COINS_PER_BLOCK = 100;

export const BASE_UPGRADE_PRICE = 200;
export const UPGRADE_PRICE_GROWTH = 2;

export function blocksPerSecondForLevel(level: number): number {
  if (level <= 1) return FACTORY_LEVELS_BPS[0];
  if (level >= MAX_FACTORY_LEVEL)
    return FACTORY_LEVELS_BPS[MAX_FACTORY_LEVEL - 1];
  return FACTORY_LEVELS_BPS[level - 1];
}

export function upgradePriceForLevel(level: number): number {
  return Math.round(
    BASE_UPGRADE_PRICE * Math.pow(UPGRADE_PRICE_GROWTH, level - 1)
  );
}
