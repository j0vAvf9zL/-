import { isDatabaseAvailable } from "./db";
import { getFactoryState, produceFactoryBlock } from "./models";

const ENGINE_KEY = "__factoryEngineV1";

interface EngineHandle {
  timer: ReturnType<typeof setTimeout> | null;
}

function engineHandle(): EngineHandle {
  const globalRef = globalThis as Record<string, unknown>;
  if (!globalRef[ENGINE_KEY]) {
    globalRef[ENGINE_KEY] = { timer: null };
  }
  return globalRef[ENGINE_KEY] as EngineHandle;
}

export async function ensureFactoryEngineStarted(): Promise<void> {
  if (!(await isDatabaseAvailable())) return;

  const handle = engineHandle();
  if (handle.timer) return;

  const run = async () => {
    try {
      const state = await getFactoryState();
      const intervalMs = Math.max(Math.round(1000 / state.blocksPerSecond), 15);
      handle.timer = setTimeout(run, intervalMs);
      await produceFactoryBlock();
    } catch (error) {
      console.error("Ошибка цикла автоматической фабрики:", error);
      handle.timer = setTimeout(run, 3000);
    }
  };

  handle.timer = setTimeout(run, 1000);
}
