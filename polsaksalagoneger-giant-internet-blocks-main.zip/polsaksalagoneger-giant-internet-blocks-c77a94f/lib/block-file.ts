// Генерация настоящих данных блока.
// Файл-блок размером 10 ГБ не хранится на диске: его байты детерминированно
// вычисляются из номера блока и стримятся при скачивании. Повторное скачивание
// одного блока всегда даёт идентичное содержимое.

export const BLOCK_SIZE_BYTES = 10_000_000_000;
export const BLOCK_SIZE_GB = 10;
export const TARGET_BLOCK_COUNT = 1_000_000_000_000;
// Время «генерации» блока: сразу после выпуска блок считается готовящимся,
// спустя это время он становится готовым к скачиванию.
export const BLOCK_GENERATION_MS = 3_000;

const CHUNK_SIZE = 4 * 1024 * 1024;

function splitmix32(a: number): () => number {
  return function () {
    a |= 0;
    a = (a + 0x9e3779b9) | 0;
    let t = a ^ (a >>> 16);
    t = Math.imul(t, 0x21f0aaad);
    t = t ^ (t >>> 15);
    t = Math.imul(t, 0x735a2d97);
    return (t = t ^ (t >>> 15)) >>> 0;
  };
}

export function generateBlockChunk(
  blockNumber: number,
  chunkIndex: number,
  size: number
): Buffer {
  const buffer = Buffer.allocUnsafe(size);
  const seed = (blockNumber ^ Math.imul(chunkIndex + 1, 0x85ebca6b)) >>> 0;
  const rand = splitmix32(seed);
  for (let offset = 0; offset < size; offset += 4) {
    buffer.writeUInt32BE(rand(), offset);
  }
  return buffer;
}

export function createBlockDataStream(
  blockNumber: number,
  sizeBytes: number = BLOCK_SIZE_BYTES
): ReadableStream<Uint8Array> {
  const totalChunks = Math.ceil(sizeBytes / CHUNK_SIZE);
  let index = 0;

  return new ReadableStream<Uint8Array>({
    pull(controller) {
      if (index >= totalChunks) {
        controller.close();
        return;
      }
      const remaining = sizeBytes - index * CHUNK_SIZE;
      const size = Math.min(CHUNK_SIZE, remaining);
      controller.enqueue(generateBlockChunk(blockNumber, index, size));
      index++;
    },
  });
}
